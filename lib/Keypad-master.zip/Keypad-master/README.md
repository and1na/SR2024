# Keypad

Implements a simple polled driver for 4x4 keypads.

Supports simple text entry, including Nokia-SMS style multi-press sequences to achieve the full alphabet.
